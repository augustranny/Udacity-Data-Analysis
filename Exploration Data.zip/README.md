DATASET

Each of the 113,937 loans in the Propser Loan Data Set has 81 variables, including the loan amount, borrower rate (or interest rate), current loan status, borrower income, and many more. 

The dataset includes data on peer-to-peer loans made possible by the Prosper credit firm.

It is well known that several parameters, including the borrower's credit score, debt-to-income ratio, employment history, income, loan term, and loan amount, are typically taken into account by credit companies when deciding the interest rates for loans to be issued to its borrowers. 

For the purpose of this investigation I have taken the following variables: 'Term', 'LoanStatus', 'BorrowerAPR', 'ProsperScore', 'ListingCategory (numeric)', 'EmploymentStatus', 'EmploymentStatusDuration', 'IsBorrowerHomeowner', 'DebtToIncomeRatio', 'StatedMonthlyIncome', 'LoanOriginalAmount', 'LoanOriginationDate', 'MonthlyLoanPayment

SUMMARY OF FINDINGS

The loan company started operations in 2005 with initial of just 22 loans. There was a gradual increase until 2008 when loans dropped to 2047 from 1152.However, there was a record high in 2013.

Loans for a 60-month duration are concentrated more on higher loan amounts and have borrowers' annual rate percentages between 0.1 and 0.35.

The 36 months term loans have borrowers annual rate percentage between 0 - 0.4 with a few outliers going to 0.5.

whereas loans for a 12-month term are primarily for low loan amounts and have borrowers' annual rate percentages between 0 and 0.35.

The loan amount is directly proportional to the term status given for loan repayment.Borrowers that own homes have more employment history than their non home ownwers.

Also, non-homeowners primarily borrowed amounts between $0 and $5,000 with a maximum of $30,000. 
Even though the majority of homeowners ranged in income from $5,000 and upwards,

Home owner borrowers have longer job histories than non home onwers, and non-owners often received loans in the range of $0 to $5,000 with a maximum of $30,000. While the majority of homeowners were dispersed among various quantities between 5000 and above.

KEY INSIGHTS FOR PRESENTATION

I concentrated my research for this project on identifying the variables that affect the borrower's annual rate %.

Out of the 81 original variables,13 variables were selected by me, and I then began to examine the distribution of each variable individually using histogram plots for continuous variables and counplots for discrete and nominal variables.

To give a general picture of the variables that have any kind of correlation with one another for the bivariate analysis, I first created a correlation map. I then looked into the relationships between those whose correlations were larger than 0.2.

After that, since the annual rate percentage of the borrower is the most visible aspect, I utilized a regression plot against the loan amount.

Various plots like boxplot, scatterplots, barplot were utilized to find the relationship between variables.

Bivariate analysis determined that the strongest features that affects the Borrowers annaual rate percentage are the LoanOriginalAmount, StatedMonthlyIncome and the MonthlyLoanPayment
